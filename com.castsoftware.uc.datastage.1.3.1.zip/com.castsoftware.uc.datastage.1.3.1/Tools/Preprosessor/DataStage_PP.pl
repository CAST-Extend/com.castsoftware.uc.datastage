@rem = '--*-Perl-*--
@echo off
if "%OS%" == "Windows_NT" goto WinNT
perl -x -S "%0" %1 %2 %3 %4 %5 %6 %7 %8 %9
goto endofperl
:WinNT
perl -x -S "%0" %*
if NOT "%COMSPEC%" == "%SystemRoot%\system32\cmd.exe" goto endofperl
if %errorlevel% == 9009 echo You do not have Perl in your PATH.
goto endofperl
@rem ';
#perl2exe_include File/Copy
use File::Copy;
#!perl
#line 14
#########################################################################
#           DATASTAGE PREPROCESSOR FOR UNIVERSAL ANALYZER              #
#########################################################################
# DATE     | DEV | DESCRIPTION                                          #
#==========+=====+======================================================#
# 21/08/12 	|GJW | Creation of the pre-processor                        #
#----------+-----+------------------------------------------------------#
#########################################################################

## Test of debug mode
if (@ARGV >= 1 && $ARGV[0] eq "DEBUG")
{
	$Debug = 1;
	shift(@ARGV);
}
else
{ $Debug = 0; }

## Program name and description
my $progName = "MODSQL_PP";
my $progDesc = "MODSQL Pre Processor";
my $pgmFlag = "0";
&REPORT( 1,"pgmFlag '$pgmFlag'" );

my $tryBlockLevel = 0; #level value 0 means no try catch block
my $otherBlocksLevelInTry = 0; #this is to take care of If block or any other block to exactly identify "end" of try block

## Test the command line
my $MySyntax = "Syntax: $progName <source path> <target path> <report file> ";
die("\nError with parameters.\n$MySyntax\n") unless (@ARGV == 3);

## Input parameters
# Describes the source of the XML Files
$Source_Path			= $ARGV[0];
# Describes the path where the files need to written to
$Target_Path			= $ARGV[1];
# Report file path and name
$Report_FullFileName	= $ARGV[2];

## Write the beginning banner on the screen
&Header;

## Openning the report file
die( "Unable to create file '$Report_FullFileName'\n" )
	unless( open(REPORT_OUT_FILE,">$Report_FullFileName") );

## Global variables
## Files processing
&ComputeFiles;

## Close the report file
close(REPORT_OUT_FILE);

## Write the end banner on the screen
&Footer;

####################################################################################################
sub Header
{
	print "\n";
	print "==================================================\n";
	print " $progName\n";
	print "==================================================\n";
	print "    - Source directory : $Source_Path\n";
	print "    - Target directory : $Target_Path\n";
	print "    - Report file      : $Report_FullFileName\n";
	print "==================================================\n";
	print "\n";
}
####################################################################################################
sub ComputeFiles
{
	# Input files list
	@files = ();
	&BuildFileList($Source_Path, ".dsx", \@files, 1 );

	&REPORT("$progDesc\n\nBeginning of process...");

	my $MyFileCounter = @files + 0;
	my $MyMaxFileCounter = $MyFileCounter;

	###################################################################################################
	# Loop on each source file and extract all the artifacts from the XML Files

	print "Start processing of SOURCE Files\n";
	
	&REPORT( 1,"My files are '@files'" );
	
	foreach $Source_FullFileName(@files)
	{
		print $MyFileCounter--."/".$MyMaxFileCounter." ";
		&ComputeFile($Source_FullFileName);
	}
	
	
	
	&REPORT("\nEnd of process.");
}
####################################################################################################
sub ComputeFile
{
	# Parameters
	my( $MySource_FullFileName ) = @_;

	&REPORT( "\n- Processing file '$MySource_FullFileName'" );
	# print "- Processing file '$MySource_FullFileName'\n";

	# Test if input file is not empty
	if ( -z $MySource_FullFileName )
	{
		&REPORT( 1,"File '$MySource_FullFileName' is empty." );
	}
	else
	{
		# Open source file
		if( open( SOURCE_IN_FILE,"<$MySource_FullFileName" ) )
		{
			
			
			my $MyPath;
			my $MyFileName;
			my $MyExtension;
			&FullFileNameToPathFileNameAndExtension( $MySource_FullFileName, \$MyPath, \$MyFileName, \$MyExtension );

			# Instantiate common variables....
			my @InstanceBody = ();
			my $MyMODSQLFOUND= "FALSE";
			my $MyArtifactName = "";
			
			# Read the source file
			my $MyLine=<SOURCE_IN_FILE>;

			while ( defined( $MyLine ) )
			{
				# Remove the '\n' from the input line
				chomp $MyLine;
							
				push( @InstanceBody, $MyLine );

				
				# Read the source file
				$MyLine=<SOURCE_IN_FILE>;
			}
			# Close the source file
			close( SOURCE_IN_FILE );


			##############################################
			## START OF TARGET FILE CREATION ##
			##############################################
		
			
				
				#Write to target folder
				
				#### BUILD UP FILE NAME ,  CREATE FILE
				
				#my $MyTarget_FullFileName = $MySource_FullFileName;
				#$MyTarget_FullFileName =~ s/$Source_Path/$Target_Path/gi;
			
				#CreatePath ($MyTarget_FullFileName);
			
				## Open target file
				#die( "Unable to create  file '$MyTarget_FullFileName'\n" )
				#s		unless( open( TARGET_OUT_FILE,">$MyTarget_FullFileName" ) );
			
						
				my $MyInstanceSize = @InstanceBody + 0;
				my $JobNameFound = "FALSE";
				my $DSSUBRECFOUND = "FALSE";
				my $DSJOBSTART = "FALSE";
				my $DSROUTINESTART = "FALSE";
				my $ENDJOB = "FALSE";
				
				my $SourceTableFound = "TRUE";
				
				
				for ( my $MyIt = 0 ; $MyIt < $MyInstanceSize ; $MyIt++ )
				{
						
						my $MyOutput = $InstanceBody[$MyIt];
						
						
						
						if ($MyOutput =~ /BEGIN DSJOB/)
						{
							&REPORT( 1,"Found start DS_JOB" );
							$DSJOBSTART = "TRUE";
							$ENDJOB = "FALSE";
						}
						
						
						
						if ($MyOutput =~ /BEGIN DSROUTINE/)
						{
							&REPORT( 1,"Found start DS_ROUTINE" );
							$DSROUTINESTART = "TRUE";
							$ENDJOB = "FALSE";
						}
						
						if($MyOutput =~ /^[ \t]*Identifier[ \t]+[\"]([a-zA-Z0-9_]+)/ && $DSJOBSTART eq "TRUE")
						{
								$DSJOBSTART = "FALSE";
								my $Jobname = $1;
								&REPORT( 1,"Found start DS_JOB and identified $Jobname" );
								
								$MyPath =~ s/$Source_Path/$Target_Path/gi;
								my $MyTarget_FullFileName = $MyPath."\\".$Jobname.".dsxcast";
											
								CreatePath ($MyTarget_FullFileName);
			
								## Open target file
								die( "Unable to create  file '$MyTarget_FullFileName'\n" )
										unless( open( TARGET_OUT_FILE,">$MyTarget_FullFileName" ) );
								print TARGET_OUT_FILE "BEGIN DSJOB\n";	
						}
						if($MyOutput =~ /^[ \t]*Identifier[ \t]+[\"]([a-zA-Z0-9_]+)/ && $DSROUTINESTART eq "TRUE")
						{
								$DSROUTINESTART = "FALSE";
								my $Jobname = $1;
								&REPORT( 1,"Found start DS_JOB and identified $Jobname" );
								
								$MyPath =~ s/$Source_Path/$Target_Path/gi;
								my $MyTarget_FullFileName = $MyPath."\\".$Jobname.".dsxcast";
											
								CreatePath ($MyTarget_FullFileName);
			
								## Open target file
								die( "Unable to create  file '$MyTarget_FullFileName'\n" )
										unless( open( TARGET_OUT_FILE,">$MyTarget_FullFileName" ) );
								print TARGET_OUT_FILE "BEGIN DSROUTINE\n";	
						}
						
						if($MyOutput =~ /^L\$([a-zA-Z0-9_]+[\$]*[a-zA-Z0-9_]*)[\:]$/)
						{
							$JobNameFound = "TRUE";	
							
							my $JobName = $1;
							print TARGET_OUT_FILE "END_JOB\n";
							print TARGET_OUT_FILE "BEGIN_JOB($JobName)\n";
							
							
						}
						if($MyOutput =~ /BEGIN DSSUBRECORD/ && $JobNameFound eq "TRUE")
						{
							print TARGET_OUT_FILE "END_JOB\n";
							$JobNameFound = "FALSE";	
						}
						
						if($MyOutput =~ /BEGIN DSSUBRECORD/)
						{
							$DSSUBRECFOUND = "TRUE"
						}
						
						if($MyOutput =~ /^[ \t]+NULLIndicatorPosition/)
						{
							$DSSUBRECFOUND = "FALSE"
						}
						
						if($MyOutput =~ /END DSRECORD/)
						{
							$DSSUBRECFOUND = "FALSE"
						}
						
					
						
						
						if ($MyOutput =~ /END DSJOB/ || $MyOutput =~ /END DSROUTINES/ )
						{
							$ENDJOB = "TRUE";
							print TARGET_OUT_FILE "$MyOutput\n";	
						}
						
						if ($DSSUBRECFOUND eq "FALSE" && $ENDJOB eq "FALSE" ) 
						{
							print TARGET_OUT_FILE "$MyOutput\n";	
						}
						
						#CHECK USE OF THE TABLES FOR END POINT FP
						if ($MyOutput =~ /[\"]INSERT[ \t]+INTO[ \t]+([a-zA-Z0-9_]+)[ \t]+/)
						{
							&REPORT( 1,"Found start INSERT STATEMENT" );
							my $Tablename = $1;
							print TARGET_OUT_FILE "$MyOutput\n";	
							print TARGET_OUT_FILE "<INSERT_TABLE>$Tablename</INSERT_TABLE>\n";
						}
						
						if ($MyOutput =~ /[\"]INSERT[ \t]+INTO[ \t]+[a-zA-Z0-9_]+[\.]([a-zA-Z0-9_]+)/)
						{
							&REPORT( 1,"Found start INSERT STATEMENT" );
							my $Tablename = $1;
							print TARGET_OUT_FILE "$MyOutput\n";	
							print TARGET_OUT_FILE "<INSERT_TABLE>$Tablename</INSERT_TABLE>\n";
						}
						
						
						if ($MyOutput =~ /[\"]UPDATE[ \t]+([a-zA-Z0-9_]+)[ \t]+/)
						{
							&REPORT( 1,"Found start UPDATE STATEMENT" );
							my $Tablename = $1;
							print TARGET_OUT_FILE "$MyOutput\n";	
							print TARGET_OUT_FILE "<UPDATE_TABLE>$Tablename</UPDATE_TABLE>\n";
						}
						if ($MyOutput =~ /[\"]UPDATE[ \t]+[a-zA-Z0-9_]+[\.]([a-zA-Z0-9_]+)/)
						{
							&REPORT( 1,"Found start UPDATE STATEMENT" );
							my $Tablename = $1;
							print TARGET_OUT_FILE "$MyOutput\n";	
							print TARGET_OUT_FILE "<UPDATE_TABLE>$Tablename</UPDATE_TABLE>\n";
						}
						
						if ($MyOutput =~ /[\"]FROM[ \t]+([a-zA-Z0-9_]+)[ \t\,]+/)
						{
							&REPORT( 1,"Found start INSERT STATEMENT" );
							my $Tablename = $1;
							print TARGET_OUT_FILE "$MyOutput\n";	
							print TARGET_OUT_FILE "<INSERT_TABLE>$Tablename</INSERT_TABLE>\n";
						}
						
						#SOURCE_TABLE
						if ($MyOutput =~ /Name[ \t]+[\"]SOURCETABLES/)
						{
							&REPORT( 1,"Found start SOURCETABLE" );
							my $Tablename = $1;
							$SourceTableFound = "TRUE";
							print TARGET_OUT_FILE "$MyOutput\n";	
							#print TARGET_OUT_FILE "<INSERT_TABLE>$Tablename</INSERT_TABLE>\n";
						}
						
						if ($MyOutput =~ /Value[ \t]+[\"][\#]DB2SCHEMA_STR_PARM[\#][\.]([a-zA-Z0-9_]+)[\"]/ && $SourceTableFound eq "TRUE" ||
						$MyOutput =~ /Value[ \t]+[\"][\#]DB2SCHEMA_STR_PARM[\#][\.]([a-zA-Z0-9_]+)[ \t,]+[\#]DB2SCHEMA_STR_PARM[\#][\.]([a-zA-Z0-9_]+)[\"]/ && $SourceTableFound eq "TRUE")
						{
							&REPORT( 1,"Found start SOURCETABLE values" );
							my $Tablename = $1;
							my $Tablename2 = $2;
							$SourceTableFound = "FALSE";
							print TARGET_OUT_FILE "$MyOutput\n";	
							print TARGET_OUT_FILE "<SOURCE_TABLEUPDATE>$Tablename</SOURCE_TABLEUPDATE>\n";
							if ($Tablename2 ne "")
							{
								print TARGET_OUT_FILE "<SOURCE_TABLEUPDATE>$Tablename2</SOURCE_TABLEUPDATE>\n";
							}
						}
						
						
						
					
						
				}
				#print TARGET_OUT_FILE "END_PROC\n";
				close( TARGET_OUT_FILE );
				
			
			
						
	
		}
		else
		{
			&REPORT( 2,"Unable to open file '$MySource_FullFileName'." );
		}
	}
}



####################################################################################################
sub ComputeFile_CodeDepth
{
	# Parameters
	my( $MySource_FullFileName ) = @_;
	$MySource_FullFileName =~ s/$Source_Path/$Target_Path/gi;

	&REPORT( "\n- Processing file '$MySource_FullFileName'" );
	 # print "- Processing file '$MySource_FullFileName'\n";

	# Test if input file is not empty
	if ( -z $MySource_FullFileName )
	{
		&REPORT( 1,"File '$MySource_FullFileName' is empty." );
	}
	else
	{
		# Open source file
		if( open( SOURCE_IN_FILE,"<$MySource_FullFileName" ) )
		{
			
				
			my $MyPath;
			my $MyFileName;
			my $MyExtension;
			&FullFileNameToPathFileNameAndExtension( $MySource_FullFileName, \$MyPath, \$MyFileName, \$MyExtension );

			# Instantiate common variables....
			my @InstanceBody = ();
			
			my $MyCodeLevel = 1;
			my $MyProcedureInside =  "FALSE";

			#Define common artifact name
			my $MyArtifact = "";

			# Read the source file
			my $MyLine=<SOURCE_IN_FILE>;

			while ( defined( $MyLine ) )
			{
				# Remove the '\n' from the input line
				chomp $MyLine;

				push( @InstanceBody, $MyLine );
				# Read the source file
				$MyLine=<SOURCE_IN_FILE>;
			}
			# Close the source file
			close( SOURCE_IN_FILE );


			##############################################
			## START OF TARGET FILE CREATION ##
			##############################################
			#Write to target folder
			my $MyInstanceSize = @InstanceBody + 0;
			#### BUILD UP FILE NAME ,  CREATE FILE
			my $MyTarget_FullFileName = $MySource_FullFileName;
			#$MyTarget_FullFileName =~ s/$Source_Path/$Target_Path/gi;
			
			CreatePath ($MyTarget_FullFileName);
			## Open target file
			die( "Unable to create  file '$MyTarget_FullFileName'\n" )
					unless( open( TARGET_OUT_FILE,">$MyTarget_FullFileName" ) );
		
		
			my $InstanceBody = @InstanceBody + 0;	
			#Put file content into target file
			for ( my $MyIt = 0 ; $MyIt < $InstanceBody ; $MyIt++ )
				{
					my $MyOutput = $InstanceBody[$MyIt];
					
					#Detect whether inside Procedure or not
					if (
					 
							$MyOutput =~ /^[ \t]*procedure[ \t]+/i 	
						||	$MyOutput =~ /^[ \t]*function[ \t]+/i
						
						)
					{
						$MyProcedureInside =  "TRUE";
						&REPORT( 1,"Line $MyIt: Inside Procedure'$MyProcedureInside';Codeline = $MyOutput" );
						
						$MyCodeLevel =  1;
					}
					
					
					if ($MyProcedureInside eq "TRUE")
					{
						#Detect additional depth level
						if (
						 		$MyOutput =~ /^[ \t]*do[ \t]*[:][ \t]*/i 
						 	#|| $MyOutput =~ /^[ \t]*do[a-zA-Z0-9_\=\%\$\#\- \t]+[:][ \t]*/i 	
						 	|| $MyOutput =~ /^[ \t]*else[ \t]+do[ \t]*[:][ \t]*/i 	
						 	|| $MyOutput =~ /^[ \t]*then[ \t]+do[ \t]*[:][ \t]*/i 	
							|| $MyOutput =~ /^[ \t]*procedure[ \t]+/i 
							|| $MyOutput =~ /^[ \t]*for[ \t]+each[ \t]+/i 
							|| $MyOutput =~ /^[ \t]*repeat[ \t]+/i 
							|| $MyOutput =~ /^[ \t]*case[a-zA-Z0-9_\=\%\$\#\- \t\.]+[:][ \t]*/i 	
							#|| $MyOutput =~ /^[ \t]*assign[ \t]+/i 
							)
						{
							$MyCodeLevel =  $MyCodeLevel +1;
							&REPORT( 1,"Line $MyIt: My Code level is now '$MyCodeLevel'; Codeline = $MyOutput" );
						
						}
						
						#Detect Level Up depth level
						if (
						 		$MyOutput =~ /^[ \t]*end[ \t]*[\.]/i 
							|| $MyOutput =~ /^[ \t]*end[ \t]+procedure[ \t]*[\.]/i 
							|| $MyOutput =~ /^[ \t]*end[ \t]+case[ \t]*[\.]/i 
							)
						{
							$MyCodeLevel =  $MyCodeLevel -1;
							&REPORT( 1,"Line $MyIt: My Code level is now '$MyCodeLevel'; Codeline = $MyOutput" );
						
						}
						
						if ($MyCodeLevel eq 1 && $MyProcedureInside eq "TRUE" )
						{
									print TARGET_OUT_FILE "END_PROCEDURE\n";
									&REPORT( 1,"Line $MyIt: Writing end tag; Codeline = $MyOutput" );
									$MyProcedureInside =  "FALSE";
						}
						
					} # END FOR
					
					#&REPORT( 1,"My content '$InstanceBody'" );
					print TARGET_OUT_FILE "$InstanceBody[$MyIt]\n";
					
				}
			
					
			# Close the source file
			close( TARGET_OUT_FILE );
			
		
		}
		else
		{
			&REPORT( 2,"Unable to open file '$MySource_FullFileName'." );
		}
	}
}
####################################################################################################
sub CreatePath
{
	my ($MyPath) = @_;

	#print "Creating path $MyPath...\n";

	my $MyRC = 1;

	my @MyTokens = split( /\\/, $MyPath );
	my $MyTmpPath = "";

	&REPORT( "Start creating directory structure using==>  @MyTokens " );
	my $MyInstanceSize = @MyTokens + 0;

	for ( my $MyIt = 0 ; $MyIt < $MyInstanceSize - 1 ; $MyIt++ )
	{
		if ( $MyTmpPath ne "" )
		{
			$MyTmpPath = $MyTmpPath . "\\" . $MyTokens[$MyIt];
		}
		else
		{
			$MyTmpPath = $MyTokens[$MyIt];
		}

		if ( -e $MyTmpPath )
		{
			#return 0;
		}
		else
		{
			mkdir( $MyTmpPath ) || return -1;
		}
	}

	return $MyRC;
}
####################################################################################################
sub BuildFileList
{
	my( $path, $fPattern, $listPointer, $recursive ) = @_;
	my( $file );
	my( $fullName );
	my( $DIR );

	# Liste des fichiers du repertoire
	if ( opendir( $DIR, $path ) )
	{
		# Lecture du premier nom de fichier
		$file = readdir( $DIR );

		# Boucle tant que le nom de fichier est trouv�
		while( defined($file) )
		{
			# Calcul du nom complet
			$fullName = $path . "\\" . $file;

			# Test de validit�
			if ( ( $fullName !~ /[\/\\]\.+$/o ) && ( -d $fullName || $file =~ /$fPattern/o ) )
			{
				# Test si c'est un repertoire ou un fichier
				if ( -f $fullName )
				{
					# Ajout a la liste
					#if ($fullName =~ m/\.p$/ || $fullName =~ m/\.i$/ || $fullName =~ m/\.w$/)
					if (-f $fullName)
					{
						push( @$listPointer, $fullName );
					}
				}
				elsif ( -d $fullName && $recursive )
				{
					# Appel recursif sur le sous rep
					&BuildFileList( $fullName, $fPattern, $listPointer, $recursive );
				}
			}

			# Lecture du nom de fichier suivant
			$file = readdir( $DIR );
		}
	}
	else
	{
		&REPORT(3,"The directory '$path' does not exist!");
	}

	# Fermeture de la liste des fichiers du repertoire
	close( $DIR );
}
####################################################################################################

sub FullFileNameToPathFileNameAndExtension
{
	# Recuperation des parametres
	my ($MyFullFileName,$MyPath,$MyFileName,$MyExtension) = @_;

	# Calcul du nom des fichiers cibles
	$MyFullFileName =~ /^(.+)\\([^\\]+)$/o;
	my $MySource_Path = $1;
	my $MySource_FileName = $2;
	my $MySource_Extension = "";

	if ($MySource_FileName =~ /^(.+)\.([^\.]*)$/o)
	{
		$MySource_FileName = $1;
		$MySource_Extension = $2;
	}

	$$MyPath = $MySource_Path;
	$$MyFileName = $MySource_FileName;
	$$MyExtension = $MySource_Extension;
}

####################################################################################################

sub ExtractRelativePath
{
	# Recuperation des parametres
	my ($MyPath,$MyRootPath) = @_;

	# Calcul du chemin "Relatif" (sans le chemin racine)
	my $MyRelativePath = "";
	my $MyRootPath = uc($MyRootPath);
	my $MyQMRootPath = quotemeta($MyRootPath);
	if (uc($MyPath) =~ /$MyQMRootPath(.*)/g || uc($MyPath) =~ /$MyRootPath(.*)/g)
	{
		$MyRelativePath = $1;
	}
	else
	{
		$MyRelativePath = $MyPath;
		&REPORT(1,"Le chemin '$MyPath' ne contient pas la racine '$MyRootPath' (ni '$MyQMRootPath')");
	}

	# Renvoi du resultat
	return $MyRelativePath;
}

####################################################################################################

sub LTrim
{
# Retire les ' ' et <tab> en debut de chaine
	my ($MySource) = @_;
	$MySource =~ s/^[ \t]+//gio;
	return $MySource;
}

####################################################################################################

sub RTrim
{
# Retire les ' ' et <tab> en fin de chaine
	my ($MySource) = @_;
	$MySource =~ s/[ \t]+$//gio;
	return $MySource;
}

####################################################################################################

sub Trim
{
# Retire les ' ' et <tab> en debut et fin de chaine
	my ($MySource) = @_;
	return &LTrim(&RTrim($MySource));
}

####################################################################################################

sub NChar
{
# Renvoi une chaine de n fois le caractere C
	my ($MyChar,$MyNum) = @_;
	my $MyResult = "";

	my $i=1;
	while ($i <= $MyNum)
	{
		$MyResult = $MyResult.$MyChar;
		$i++
	}

	return $MyResult;
}

####################################################################################################

sub PTrim
{
# Retire les '\' et '/' en debut et fin de chaine
	my ($MyPath) = @_;
	$MyPath =~ s/^[\\\/]+//gio;
	$MyPath =~ s/[\\\/]+$//gio;
	return $MyPath;
}

####################################################################################################

sub Tokenize
{
# Exemple :
#
#$Text = "Bonjour tout le monde \"du petit village\" dans les nuages";
#
#@Token_List = ();
#&Tokenize($Text," ", "\"", \@Token_List);
#
#foreach $Token(@Token_List)
#{
#	print $Token."\n";
#}

	# Recuperation des parametres
	my ($MyText,$MySeparatorChar,$MyConstChar,$listPointer) = @_;

	# Decoupage de la chaine en mots separes par un caractere sauf � l�interieur d�un autre caractere
	# Typiquement : decoupage d'un statement par l'espace sauf entre guillemets
	use Text::ParseWords;
	@$listPointer = quotewords($MySeparatorChar, $MyConstChar, $MyText);

}

####################################################################################################

sub Tokenize2
{
# Exemple :
#
#$Text = "Bonjour tout \(le \(monde\) du\) \(petit village\) dans les nuages";
#
#@Token_List = ();
#&Tokenize($Text, " ", "\(", "\)", \@Token_List);
#
#foreach $Token(@Token_List)
#{
#	print $Token."\n";
#}

	# Recuperation des parametres
	my ($MyText,$MySeparatorChar,$MyOpenChar,$MyCloseChar,$listPointer) = @_;

	my $S = index($MyText,$MySeparatorChar);
	my $O = index($MyText,$MyOpenChar);
	my $C = &CloseIndex($MyText,$O,$MyOpenChar,$MyCloseChar);

	my $i = 0;

	while ($S > -1 && $i < 10)
	{
		if ($S < $O && $S < $C)
		{
			$SubText = substr($MyText,0,$S);
			push(@$listPointer,$SubText);

			$MyText = substr($MyText,$S + 1);

			$S = index($MyText,$MySeparatorChar);
			$O = index($MyText,$MyOpenChar);
			$C = &CloseIndex($MyText,$O,$MyOpenChar,$MyCloseChar);
		}
		elsif ($S > $O && $S < $C)
		{
			$S = index($MyText,$MySeparatorChar,$S + 1);
		}
		elsif ($S > $O && $S > $C)
		{
			$SubText = substr($MyText,0,$S);
			push(@$listPointer,$SubText);

			$MyText = substr($MyText,$S + 1);

			$S = index($MyText,$MySeparatorChar);
			$O = index($MyText,$MyOpenChar);
			$C = &CloseIndex($MyText,$O,$MyOpenChar,$MyCloseChar);
		}
		$i++;
	}
	if (length($MyText) > 0)
	{
		$SubText = $MyText;
		push(@$listPointer,$SubText);

		$MyText="";
	}
}

####################################################################################################

sub CloseIndex
{
	my ($MyText,$MyOpenIndex,$MyOpenChar,$MyCloseChar) = @_;

	my $MyI=$MyOpenIndex;
	my $MyNb = 1;

	while ($MyI < length($MyText) && $MyNb > 0)
	{
		$MyI++;
		my $MyChar = substr($MyText,$MyI,1);

		if ($MyChar eq $MyOpenChar)
		{
			$MyNb++;
		}
		elsif ($MyChar eq $MyCloseChar)
		{
			$MyNb--;
		}
	}
	return $MyI;
}

####################################################################################################

sub REPORT
{
	if (@_ == 1)
	{
		my ($MyMessage) = @_;

		print REPORT_OUT_FILE "$MyMessage\n";
	}
	elsif (@_ == 2)
	{
		my ($MySeverity,$MyMessage) = @_;

		if ($MySeverity eq "D" && $Debug)
		{
			print REPORT_OUT_FILE "DBG : $MyMessage\n";
		}
		elsif ($MySeverity eq 0)
		{
			print REPORT_OUT_FILE "   $MyMessage\n";
		}
		elsif ($MySeverity eq 1)
		{
			print REPORT_OUT_FILE "--> WARNING : $MyMessage\n";
		}
		elsif ($MySeverity eq 2)
		{
			print REPORT_OUT_FILE "==> SEVERE WARNING : $MyMessage\n";
		}
		elsif ($MySeverity eq 3)
		{
			print REPORT_OUT_FILE ">>> ERROR : $MyMessage\n";
		}
	}
	else
	{
		my ($MyMessage) = @_;
		print REPORT_OUT_FILE ">>> ERROR : Bad parameters for REPORT function!\n";
		die();
	}
}

####################################################################################################

sub Footer
{
	print "\n";
	print "==================================================\n";
	print "End of process\n";
	print "==================================================\n";
	print "\n";
}
####################################################################################################
__END__
:endofperl
